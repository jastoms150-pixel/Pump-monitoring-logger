let logs = JSON.parse(localStorage.getItem("pumpLogs")) || [];

function saveLog() {
  const tank = document.getElementById("tank").value;
  const pump = document.getElementById("pump").value;
  const depth = document.getElementById("depth").value;
  if (!tank || !pump || !depth) return alert("Fill all fields!");

  const log = {
    tank,
    pump,
    depth,
    time: new Date().toLocaleString()
  };
  logs.push(log);
  localStorage.setItem("pumpLogs", JSON.stringify(logs));
  displayLogs();
}

function displayLogs() {
  const logsDiv = document.getElementById("logs");
  logsDiv.innerHTML = logs.map(l => `<p>Tank ${l.tank}, Pump ${l.pump}, Depth ${l.depth}m at ${l.time}</p>`).join("");
}

function exportLogs() {
  if (logs.length === 0) return alert("No logs to export!");
  const csv = "Tank,Pump,Depth,Time\n" + logs.map(l => `${l.tank},${l.pump},${l.depth},${l.time}`).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "pump_logs.csv";
  a.click();
}

function clearLogs() {
  if (confirm("Clear all logs?")) {
    logs = [];
    localStorage.removeItem("pumpLogs");
    displayLogs();
  }
}

window.onload = displayLogs;